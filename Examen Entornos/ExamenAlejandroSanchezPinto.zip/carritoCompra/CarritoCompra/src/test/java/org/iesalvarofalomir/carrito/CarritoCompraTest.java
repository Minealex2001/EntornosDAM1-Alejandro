package org.iesalvarofalomir.carrito;

import org.junit.jupiter.api.BeforeAll;

public class CarritoCompraTest {

    @BeforeAll
    public static void getCantidadProductos() {
        
    }
}
    