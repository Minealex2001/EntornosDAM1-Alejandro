package org.iesalvarofalomir.carrito;

    
public class ProductNotFoundExceptionTest {

}
    