package org.iesalvarofalomir.calc.oper;
public class Operacion{
public static int suma(int operA, int operB){
return operA + operB;
}
public static int mult(int operA, int operB){
return operA * operB;
}
}