package org.iesalvarofalomir.calc.nuevasOperaciones;

public class operacionBis{
    public static int div(int operA, int operB){
        return operA / operB;
        }
        public static int resta(int operA, int operB){
        return operA - operB;
        }
        }
