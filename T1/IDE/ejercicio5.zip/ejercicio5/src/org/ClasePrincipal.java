package org;

import org.ClaseA;
import org.ClaseB;
import org.iesalvarofalomir.entornos.ClaseD;
import org.iesalvarofalomir.ClaseC;
/**
 *
 * @author pablo
 */
public class ClasePrincipal {
    static public void main(String[] args){
        ClaseA variableClaseA;
        ClaseB variableClaseB;
        ClaseC variableClaseC;
        ClaseD variableClaseD;
                
        System.out.println("Enhorabuena lograste compilar el programa.");
        
    }
}
