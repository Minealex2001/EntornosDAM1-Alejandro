package mis_clases.clase2;

public class Clase2 {

}
