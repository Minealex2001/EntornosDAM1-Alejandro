package paquete1;
public class Saludos {
// Devuelve la cadena Buenos dias
public static String saludoMañana() {
return "Buenos días.";
}
// Devuelve la cadena Buenas tardes
public static String saludoTarde() {
return "Buenas tardes.";
}
}
