package mis_clases.clases_publicas.clase1;
public class Clase1
{
}