package org.iesalvarofalomir.calc;
public class CalculadoraSimple{
public static void main(String[] args){
System.out.println("Vamos a multiplicar y sumar los numeros 10 y 100.");
int a = 10;
int b = 100;
System.out.println("La suma da "+ (a+b));
System.out.println("La multiplicación da "+ (a*b));
}
}
