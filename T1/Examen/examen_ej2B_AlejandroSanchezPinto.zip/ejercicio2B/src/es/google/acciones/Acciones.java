package es.google.acciones;

/**
 *
 * @author pablo
 */
public class Acciones {

    public static void salta() {
        System.out.println("saltando");
    }

    public static void corre() {
        System.out.println("corriendo");
    }

    public static void vuela() {
        System.out.println("volando");
    }
}