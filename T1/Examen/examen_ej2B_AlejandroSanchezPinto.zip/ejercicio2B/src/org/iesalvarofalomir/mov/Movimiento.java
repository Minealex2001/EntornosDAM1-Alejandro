package org.iesalvarofalomir.mov;

/**
 *
 * @author pablo
 */
public class Movimiento {

    public static void arriba() {
        System.out.println("arriba");
    }

    public static void abajo() {
        System.out.println("abajo");
    }

    public static void derecha() {
         System.out.println("derecha");
    }

    public static void izquierda() {
        System.out.println("izquierda");
    }
}
