package es.iesalvarofalomir.formas;

import org.apache.commons.lang3.ArrayUtils;

/**
 *
 * @author pablo
 */
public class Circulo {
    
    private final double radio = 3.5;
    private final double x = 0.5;
    private final double y = 3.4;

   public void devuelveValores(){
       double array[] = ArrayUtils.EMPTY_DOUBLE_ARRAY;
       array = ArrayUtils.addAll(array, radio, x, y);
       
       System.out.println("Circulo: radio = " + array[0] + ", x = " + array[1] + ", y = " + array[2]);
       
   }    
    
}
