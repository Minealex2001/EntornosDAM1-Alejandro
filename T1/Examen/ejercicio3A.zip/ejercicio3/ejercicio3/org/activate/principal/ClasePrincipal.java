package org.activate.principal;

import es.iesalvarofalomir.formas.Circulo;
import es.iesalvarofalomir.formas.Rectangulo;

/**
 *
 * @author pablo
 */
public class ClasePrincipal {

    public static void main(String [] args){
        Rectangulo r = new Rectangulo();
        Circulo c = new Circulo();
        
        r.devuelveValores();
        c.devuelveValores();
    }
}
