package es.iesalvarofalomir.formas;

import org.apache.commons.lang3.ArrayUtils;

/**
 *
 * @author pablo
 */
public class Rectangulo {

    private double ancho = 200.5;
    private double alto = 10.2;

    public void devuelveValores() {
        double array[] = ArrayUtils.EMPTY_DOUBLE_ARRAY;
        array = ArrayUtils.addAll(array, ancho, alto);

        System.out.println("Rectangulo: ancho = " + array[0] + ", alto = " + array[1]);

    }

    public double getAncho() {
        return ancho;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public double getAlto() {
        return alto;
    }

    public void setAlto(double alto) {
        this.alto = alto;
    }

}
